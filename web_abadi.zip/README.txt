CARA PAKAI:
1. Masukkan lagu Abadi milikmu ke assets/music/ dan beri nama abadi.mp3.
2. Masukkan foto kalian ke assets/foto/ dan beri nama foto-kalian.jpg.
3. Buka index.html di browser.
4. Untuk GitHub Pages, upload seluruh isi folder ini ke repository.
